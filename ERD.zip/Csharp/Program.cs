﻿using System;
using Microsoft.Data.SqlClient;

namespace SAABookingSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string connectionString = @"Data Source=TOM\MSSQLSERVER01;Initial Catalog=SAAFlightBookingDB;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;";

            string query =
                "SELECT PassengerID, FirstName, LastName, Email, Phone " +
                "FROM Passengers " +
                "ORDER BY PassengerID;";

            try
            {
                using SqlConnection connection = new SqlConnection(connectionString);

                connection.Open();

                Console.WriteLine("Database connection successful.");
                Console.WriteLine();
                Console.WriteLine("Passenger Records");
                Console.WriteLine("-----------------");

                using SqlCommand command = new SqlCommand(query, connection);
                using SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Console.WriteLine(
                        reader["PassengerID"] + " | " +
                        reader["FirstName"] + " " +
                        reader["LastName"] + " | " +
                        reader["Email"] + " | " +
                        reader["Phone"]
                    );
                }

                Console.WriteLine();
                Console.WriteLine("Finished retrieving passenger records.");
            }
            catch (SqlException ex)
            {
                Console.WriteLine("SQL Server error:");
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Application error:");
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}