USE SAAFlightBookingDB;
Go
UPDATE Payments
SET PaymentStatus = 'Paid'
WHERE PaymentID = 3;