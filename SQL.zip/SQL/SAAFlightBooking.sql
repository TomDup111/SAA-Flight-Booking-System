CREATE DATABASE SAAFlightBookingDB;
GO

USE SAAFlightBookingDB;
GO

CREATE TABLE Airports
(
    AirportID INT PRIMARY KEY,
    AirportCode VARCHAR(10) NOT NULL UNIQUE,
    AirportName VARCHAR(100) NOT NULL,
    City VARCHAR(100) NOT NULL,
    Country VARCHAR(100) NOT NULL
);
GO

CREATE TABLE Passengers
(
    PassengerID INT PRIMARY KEY,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(150) NOT NULL UNIQUE,
    Phone VARCHAR(30)
);
GO

CREATE TABLE Flights
(
    FlightID INT PRIMARY KEY,
    FlightNumber VARCHAR(20) NOT NULL UNIQUE,
    DepartureAirportID INT NOT NULL,
    ArrivalAirportID INT NOT NULL,
    DepartureDateTime DATETIME2 NOT NULL,
    ArrivalDateTime DATETIME2 NOT NULL,

    CONSTRAINT FK_Flights_DepartureAirport
        FOREIGN KEY (DepartureAirportID)
        REFERENCES Airports(AirportID),

    CONSTRAINT FK_Flights_ArrivalAirport
        FOREIGN KEY (ArrivalAirportID)
        REFERENCES Airports(AirportID),

    CONSTRAINT CK_Flights_DifferentAirports
        CHECK (DepartureAirportID <> ArrivalAirportID),

    CONSTRAINT CK_Flights_ArrivalAfterDeparture
        CHECK (ArrivalDateTime > DepartureDateTime)
);
GO

CREATE TABLE Bookings
(
    BookingID INT PRIMARY KEY,
    FlightID INT NOT NULL,
    BookingDate DATE NOT NULL,
    BookingStatus VARCHAR(20) NOT NULL,

    CONSTRAINT FK_Bookings_Flights
        FOREIGN KEY (FlightID)
        REFERENCES Flights(FlightID),

    CONSTRAINT CK_Bookings_Status
        CHECK (BookingStatus IN ('Confirmed', 'Pending', 'Cancelled'))
);
GO

CREATE TABLE BookingPassengers
(
    BookingPassengerID INT PRIMARY KEY,
    BookingID INT NOT NULL,
    PassengerID INT NOT NULL,
    SeatNumber VARCHAR(10),

    CONSTRAINT FK_BookingPassengers_Bookings
        FOREIGN KEY (BookingID)
        REFERENCES Bookings(BookingID),

    CONSTRAINT FK_BookingPassengers_Passengers
        FOREIGN KEY (PassengerID)
        REFERENCES Passengers(PassengerID),

    CONSTRAINT UQ_BookingPassenger
        UNIQUE (BookingID, PassengerID)
);
GO

CREATE TABLE Tickets
(
    TicketID INT PRIMARY KEY,
    BookingPassengerID INT NOT NULL,
    TicketNumber VARCHAR(30) NOT NULL UNIQUE,
    TicketStatus VARCHAR(20) NOT NULL,
    TicketPrice DECIMAL(10,2) NOT NULL,

    CONSTRAINT FK_Tickets_BookingPassengers
        FOREIGN KEY (BookingPassengerID)
        REFERENCES BookingPassengers(BookingPassengerID),

    CONSTRAINT CK_Tickets_Status
        CHECK (TicketStatus IN ('Issued', 'Cancelled')),

    CONSTRAINT CK_Tickets_Price
        CHECK (TicketPrice >= 0)
);
GO

CREATE TABLE Payments
(
    PaymentID INT PRIMARY KEY,
    BookingID INT NOT NULL,
    PaymentDate DATE NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    PaymentStatus VARCHAR(20) NOT NULL,

    CONSTRAINT FK_Payments_Bookings
        FOREIGN KEY (BookingID)
        REFERENCES Bookings(BookingID),

    CONSTRAINT CK_Payments_Amount
        CHECK (Amount >= 0),

    CONSTRAINT CK_Payments_Status
        CHECK (PaymentStatus IN ('Paid', 'Pending', 'Refunded'))
);
GO