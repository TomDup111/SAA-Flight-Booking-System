USE SAAFlightBookingDB;
SELECT
    P.FirstName + ' ' + P.LastName AS PassengerName,
    F.FlightNumber,
    B.BookingID,
    B.BookingStatus,
    BP.SeatNumber
FROM Bookings B
INNER JOIN Flights F
    ON B.FlightID = F.FlightID
INNER JOIN BookingPassengers BP
    ON B.BookingID = BP.BookingID
INNER JOIN Passengers P
    ON BP.PassengerID = P.PassengerID
ORDER BY P.LastName;