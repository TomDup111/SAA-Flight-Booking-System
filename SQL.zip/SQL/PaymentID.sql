SELECT
    PaymentID AS [Payment ID],
    BookingID AS [Booking ID],
    PaymentDate AS [Payment Date],
    Amount AS [Payment Amount],
    PaymentStatus AS [Payment Status]
FROM Payments
ORDER BY PaymentDate;