SELECT
    BookingID AS [Booking ID],
    FlightID AS [Flight ID],
    BookingDate AS [Booking Date],
    BookingStatus AS [Booking Status]
FROM Bookings
WHERE BookingStatus = 'Confirmed'
ORDER BY BookingDate;