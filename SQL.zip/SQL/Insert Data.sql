USE SAAFlightBookingDB;
GO

INSERT INTO Airports
(AirportID, AirportCode, AirportName, City, Country)
VALUES
(1, 'JNB', 'O.R. Tambo International Airport', 'Johannesburg', 'South Africa'),
(2, 'CPT', 'Cape Town International Airport', 'Cape Town', 'South Africa'),
(3, 'DUR', 'King Shaka International Airport', 'Durban', 'South Africa');
GO

INSERT INTO Passengers
(PassengerID, FirstName, LastName, Email, Phone)
VALUES
(1, 'Thabo', 'Mokoena', 'thabo.mokoena@example.com', '0821111111'),
(2, 'Lerato', 'Dlamini', 'lerato.dlamini@example.com', '0822222222'),
(3, 'Sipho', 'Nkosi', 'sipho.nkosi@example.com', '0823333333'),
(4, 'Anele', 'Mthembu', 'anele.mthembu@example.com', '0824444444'),
(5, 'Karabo', 'Molefe', 'karabo.molefe@example.com', '0825555555');
GO

INSERT INTO Flights
(FlightID, FlightNumber, DepartureAirportID, ArrivalAirportID, DepartureDateTime, ArrivalDateTime)
VALUES
(1, 'SA101', 1, 2, '2026-10-05 08:00', '2026-10-05 10:15'),
(2, 'SA102', 2, 1, '2026-10-06 12:00', '2026-10-06 14:15'),
(3, 'SA201', 1, 3, '2026-10-08 09:00', '2026-10-08 10:15'),
(4, 'SA202', 3, 1, '2026-10-09 15:00', '2026-10-09 16:15'),
(5, 'SA301', 2, 3, '2026-10-10 11:00', '2026-10-10 13:00');
GO

INSERT INTO Bookings
(BookingID, FlightID, BookingDate, BookingStatus)
VALUES
(1, 1, '2026-09-20', 'Confirmed'),
(2, 3, '2026-09-21', 'Confirmed'),
(3, 5, '2026-09-22', 'Pending');
GO

INSERT INTO BookingPassengers
(BookingPassengerID, BookingID, PassengerID, SeatNumber)
VALUES
(1, 1, 1, '12A'),
(2, 1, 2, '12B'),
(3, 2, 3, '18A'),
(4, 2, 4, '18B'),
(5, 3, 5, '20C');
GO

INSERT INTO Tickets
(TicketID, BookingPassengerID, TicketNumber, TicketStatus, TicketPrice)
VALUES
(1, 1, 'TKT10001', 'Issued', 1850.00),
(2, 2, 'TKT10002', 'Issued', 1850.00),
(3, 3, 'TKT10003', 'Issued', 1450.00),
(4, 4, 'TKT10004', 'Issued', 1450.00),
(5, 5, 'TKT10005', 'Issued', 1250.00);
GO

INSERT INTO Payments
(PaymentID, BookingID, PaymentDate, Amount, PaymentStatus)
VALUES
(1, 1, '2026-09-20', 3700.00, 'Paid'),
(2, 2, '2026-09-21', 2900.00, 'Paid'),
(3, 3, '2026-09-22', 1250.00, 'Pending');
GO