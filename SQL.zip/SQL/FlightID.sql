SELECT
    FlightID AS [Flight ID],
    FlightNumber AS [Flight Number],
    DepartureAirportID AS [Departure Airport],
    ArrivalAirportID AS [Arrival Airport],
    DepartureDateTime AS [Departure Time],
    ArrivalDateTime AS [Arrival Time]
FROM Flights
ORDER BY DepartureDateTime;