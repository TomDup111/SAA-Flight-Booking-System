USE SAAFlightBookingDB;
GO
UPDATE Passengers
SET Email = 'thabo.mokoena.updated@example.com'
WHERE PassengerID = 1;