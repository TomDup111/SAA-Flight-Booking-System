USE SAAFlightBookingDB;
GO
SELECT
    F.FlightNumber,
    SUM(T.TicketPrice) AS TotalRevenue
FROM Flights F
INNER JOIN Bookings B
    ON F.FlightID = B.FlightID
INNER JOIN BookingPassengers BP
    ON B.BookingID = BP.BookingID
INNER JOIN Tickets T
    ON BP.BookingPassengerID = T.BookingPassengerID
GROUP BY F.FlightNumber
ORDER BY F.FlightNumber;