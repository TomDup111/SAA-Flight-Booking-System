SELECT
    F.FlightNumber AS [Flight Number],
    A.City AS [Arrival City],
    F.ArrivalDateTime AS [Arrival Time]
FROM Flights F
INNER JOIN Airports A
    ON F.ArrivalAirportID = A.AirportID
WHERE A.City = 'Cape Town'
ORDER BY F.ArrivalDateTime;