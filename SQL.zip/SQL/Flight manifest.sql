SELECT
    F.FlightNumber,
    P.FirstName + ' ' + P.LastName AS PassengerName,
    BP.SeatNumber,
    T.TicketNumber,
    T.TicketStatus
FROM Flights F
INNER JOIN Bookings B
    ON F.FlightID = B.FlightID
INNER JOIN BookingPassengers BP
    ON B.BookingID = BP.BookingID
INNER JOIN Passengers P
    ON BP.PassengerID = P.PassengerID
INNER JOIN Tickets T
    ON BP.BookingPassengerID = T.BookingPassengerID
ORDER BY F.FlightNumber, BP.SeatNumber;