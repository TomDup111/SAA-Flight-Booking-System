SELECT
    F.FlightNumber AS [Flight Number],
    A.City AS [Departure City],
    F.DepartureDateTime AS [Departure Time]
FROM Flights F
INNER JOIN Airports A
    ON F.DepartureAirportID = A.AirportID
WHERE A.City = 'Johannesburg'
ORDER BY F.DepartureDateTime;