USE SAAFlightBookingDB;
GO
UPDATE Bookings
SET BookingStatus = 'Confirmed'
WHERE BookingID = 3;