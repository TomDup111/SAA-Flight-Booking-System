USE SAAFlightBookingDB;
GO
SELECT
    TicketStatus,
    COUNT(*) AS NumberOfTickets
FROM Tickets
GROUP BY TicketStatus;