USE SAAFlightBookingDB;
GO
SELECT
    COUNT(DISTINCT B.BookingID) AS TotalBookings,
    COUNT(DISTINCT BP.PassengerID) AS TotalPassengers,
    COUNT(DISTINCT T.TicketID) AS TotalTickets,
    SUM(T.TicketPrice) AS TotalTicketRevenue
FROM Bookings B
LEFT JOIN BookingPassengers BP
    ON B.BookingID = BP.BookingID
LEFT JOIN Tickets T
    ON BP.BookingPassengerID = T.BookingPassengerID;