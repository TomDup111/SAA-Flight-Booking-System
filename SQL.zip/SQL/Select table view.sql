USE SAAFlightBookingDB;
GO
SELECT * FROM Airports;
SELECT * FROM Passengers;
SELECT * FROM Flights;
SELECT * FROM Bookings;
SELECT * FROM BookingPassengers;
SELECT * FROM Tickets;
SELECT * FROM Payments;