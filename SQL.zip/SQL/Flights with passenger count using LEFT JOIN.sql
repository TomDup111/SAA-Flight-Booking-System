SELECT
    F.FlightNumber,
    COUNT(BP.PassengerID) AS PassengerCount
FROM Flights F
LEFT JOIN Bookings B
    ON F.FlightID = B.FlightID
LEFT JOIN BookingPassengers BP
    ON B.BookingID = BP.BookingID
GROUP BY F.FlightNumber
ORDER BY F.FlightNumber;