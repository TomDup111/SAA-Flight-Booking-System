USE SAAFlightBookingDB;
GO

SELECT
    PassengerID AS [Passenger ID],
    FirstName AS [First Name],
    LastName AS [Last Name],
    Email,
    Phone
FROM Passengers
ORDER BY LastName;